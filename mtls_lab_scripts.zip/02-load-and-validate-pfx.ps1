$PfxPath = "C:\dev\mtls\client.pfx"
$PfxPassword = "MyPassword123!"

$CertPassword = ConvertTo-SecureString $PfxPassword -AsPlainText -Force

$Cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(
    $PfxPath,
    $CertPassword
)

# Validate cert
$Cert.Subject
$Cert.HasPrivateKey
$Cert.NotAfter
