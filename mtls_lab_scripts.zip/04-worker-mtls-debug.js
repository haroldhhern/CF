export default {
  async fetch(request) {

    return Response.json({
      certVerified: request.cf?.tlsClientAuth?.certVerified,
      certIssuerSKI: request.cf?.tlsClientAuth?.certIssuerSKI,
      certSubjectDN: request.cf?.tlsClientAuth?.certSubjectDN,
      certSerial: request.cf?.tlsClientAuth?.certSerial,
      certIssuerDN: request.cf?.tlsClientAuth?.certIssuerDN,
      certSKI: request.cf?.tlsClientAuth?.certSKI
    }, {
      headers: {
        "content-type": "application/json"
      }
    })

  }
}
