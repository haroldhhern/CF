$PfxPath = "C:\dev\mtls\client.pfx"
$PfxPassword = "MyPassword123!"
$Url = "https://mtls-test.volblut.com/"

# DNS test
Resolve-DnsName mtls-test.volblut.com

# Load certificate
$CertPassword = ConvertTo-SecureString $PfxPassword -AsPlainText -Force

$Cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(
    $PfxPath,
    $CertPassword
)

# Validate cert
$Cert.Subject
$Cert.HasPrivateKey
$Cert.NotAfter

# Test WITHOUT certificate
Invoke-WebRequest -Uri $Url

# Test WITH certificate
Invoke-WebRequest `
    -Uri $Url `
    -Certificate $Cert
