# Requires PowerShell 7+

# Paths
$CertPemPath = "C:\dev\mtls\client.pem"
$KeyPemPath  = "C:\dev\mtls\client.key"
$PfxPath     = "C:\dev\mtls\client.pfx"
$PfxPassword = "MyPassword123!"

# Read PEM files
$certPem = Get-Content $CertPemPath -Raw
$keyPem  = Get-Content $KeyPemPath -Raw

# Create certificate with private key
$cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::CreateFromPem(
    $certPem,
    $keyPem
)

# Export as PFX
$pfxBytes = $cert.Export(
    [System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12,
    $PfxPassword
)

# Write PFX to disk
[System.IO.File]::WriteAllBytes($PfxPath, $pfxBytes)

# Confirm file was created
Get-Item $PfxPath
